import pytest
print("\n=== 🚗 Running Automobile Sales Analysis Tests ===\n")
pytest.main(["-v", "tests/test_from_config.py"])
