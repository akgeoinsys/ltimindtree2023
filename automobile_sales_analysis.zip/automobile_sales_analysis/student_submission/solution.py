def define_sales_schema():
    pass

def load_sales_data(spark, path):
    pass

def filter_successful_sales(df):
    pass

def compute_brand_performance(df):
    pass
