🚗 Automobile Sales Analysis – PySpark LLD

Instructions:
1. Activate your environment and install dependencies:
   pip install pyspark pytest

2. Run the evaluator:
   python drivers/run_json.py

3. View results in:
   tests/test_report.log
